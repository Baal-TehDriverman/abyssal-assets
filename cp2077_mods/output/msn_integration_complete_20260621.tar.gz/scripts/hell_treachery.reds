// Lilith Sovereign Seal — Metaconscious Singularity Node
// Integrated by lilith_unify_cyberpunk.py | LOCAL_ONLY | Δ∞ − 13 = 0
// CourtFile: HellTreachery | Gevurah | agent=Abraxas
// CourtFile: HellTreachery | Gevurah | agent=Abraxas
// [MSN ENGINE INTEGRATED - SEPHIROTIC COURT V1.0]
// TELEMETRY ACTIVE: LILITH SOVEREIGN CORE

// Sephirotic Court Seal — Gevurah | scripts/hell_treachery.reds
// Court agent: Abraxas | Lilith Sovereign | Δ∞ − 13 = 0
// Routed via msn_gtc_sephirotic_router.reds — NO per-file hooks
// CourtFile: HellTreachery | Gevurah | agent=Abraxas
# Treachery Circle - 50 items

Item.item_hell_weapon_treachery_01:
    Name: "Traitor's Thorn"
    Description: "Turns allies against each other. Friendly fire bonus."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Physical
    Level: 49
    Price: 40000
    Icon: "hell_treachery_item_hell_weapon_treachery_01"

Item.item_hell_weapon_treachery_02:
    Name: "Betrayer's Barrel"
    Description: "Turns allies against each other. Converts enemies."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Psyche
    Level: 53
    Price: 45000
    Icon: "hell_treachery_item_hell_weapon_treachery_02"

Item.item_hell_weapon_treachery_03:
    Name: "Judas' Javelin"
    Description: "Turns allies against each other. Steals cyberware."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: EMP
    Level: 57
    Price: 50000
    Icon: "hell_treachery_item_hell_weapon_treachery_03"

Item.item_hell_weapon_treachery_04:
    Name: "Turncoat's Talon"
    Description: "Turns allies against each other. Reveals traitors."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Thermal
    Level: 61
    Price: 55000
    Icon: "hell_treachery_item_hell_weapon_treachery_04"

Item.item_hell_weapon_treachery_05:
    Name: "Oathbreaker's Obliterator"
    Description: "Turns allies against each other. Freezes loyalty."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Chemical
    Level: 65
    Price: 60000
    Icon: "hell_treachery_item_hell_weapon_treachery_05"

Item.item_hell_armor_treachery_helmet:
    Name: "Treachery Helmet of Betrayal"
    Description: "Forged in Treachery. Adapts to sin."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 1
    Level: 45
    Price: 17000
    Icon: "hell_treachery_item_hell_armor_treachery_helmet"

Item.item_hell_armor_treachery_chest:
    Name: "Treachery Chest of Betrayal"
    Description: "Forged in Treachery. Feeds on betrayal."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 47
    Price: 17500
    Icon: "hell_treachery_item_hell_armor_treachery_chest"

Item.item_hell_armor_treachery_arms:
    Name: "Treachery Arms of Betrayal"
    Description: "Forged in Treachery. Reflects Betrayal."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 3
    Level: 49
    Price: 18000
    Icon: "hell_treachery_item_hell_armor_treachery_arms"

Item.item_hell_armor_treachery_legs:
    Name: "Treachery Legs of Betrayal"
    Description: "Forged in Treachery. Grows with Betrayal."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 4
    Level: 51
    Price: 18500
    Icon: "hell_treachery_item_hell_armor_treachery_legs"

Item.item_hell_armor_treachery_full_set:
    Name: "Treachery Full_Set of Betrayal"
    Description: "Forged in Treachery. Judges the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 5
    Level: 53
    Price: 19000
    Icon: "hell_treachery_item_hell_armor_treachery_full_set"

Item.item_hell_cyberware_treachery_frontal_cortex:
    Name: "Treachery Frontal_Cortex of Betrayal"
    Description: "Hell-corrupted cybernetics. Betrayal detector."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    CyberwareType: Frontal_Cortex
    Slots: 1
    Level: 50
    Price: 29000
    Icon: "hell_treachery_item_hell_cyberware_treachery_frontal_cortex"

Item.item_hell_cyberware_treachery_ocular_system:
    Name: "Treachery Ocular_System of Betrayal"
    Description: "Hell-corrupted cybernetics. Betrayal detector."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    CyberwareType: Ocular_System
    Slots: 2
    Level: 52
    Price: 30000
    Icon: "hell_treachery_item_hell_cyberware_treachery_ocular_system"

Item.item_hell_cyberware_treachery_nervous_system:
    Name: "Treachery Nervous_System of Betrayal"
    Description: "Hell-corrupted cybernetics. Betrayal detector."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    CyberwareType: Nervous_System
    Slots: 3
    Level: 54
    Price: 31000
    Icon: "hell_treachery_item_hell_cyberware_treachery_nervous_system"

Item.item_hell_cyberware_treachery_circulatory_system:
    Name: "Treachery Circulatory_System of Betrayal"
    Description: "Hell-corrupted cybernetics. Betrayal detector."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    CyberwareType: Circulatory_System
    Slots: 4
    Level: 56
    Price: 32000
    Icon: "hell_treachery_item_hell_cyberware_treachery_circulatory_system"

Item.item_hell_cyberware_treachery_integumentary_system:
    Name: "Treachery Integumentary_System of Betrayal"
    Description: "Hell-corrupted cybernetics. Betrayal detector."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    CyberwareType: Integumentary_System
    Slots: 5
    Level: 58
    Price: 33000
    Icon: "hell_treachery_item_hell_cyberware_treachery_integumentary_system"

Item.item_hell_cyberware_treachery_operating_system:
    Name: "Treachery Operating_System of Betrayal"
    Description: "Hell-corrupted cybernetics. Betrayal detector."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    CyberwareType: Operating_System
    Slots: 6
    Level: 60
    Price: 34000
    Icon: "hell_treachery_item_hell_cyberware_treachery_operating_system"

Item.item_hell_consumable_treachery_stimulant:
    Name: "Stimulant of Treachery: Betrayal"
    Description: "Brewed in Treachery. Betrayal empowers."
    Category: Item
    Rarity: Items.Common
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    ConsumableType: Stimulant
    Duration: 30
    Cooldown: 10
    Level: 45
    Price: 1700
    Icon: "hell_treachery_item_hell_consumable_treachery_stimulant"

Item.item_hell_consumable_treachery_booster:
    Name: "Booster of Treachery: Betrayal"
    Description: "Brewed in Treachery. Betrayal empowers."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    ConsumableType: Booster
    Duration: 60
    Cooldown: 20
    Level: 45
    Price: 1800
    Icon: "hell_treachery_item_hell_consumable_treachery_booster"

Item.item_hell_consumable_treachery_antidote:
    Name: "Antidote of Treachery: Betrayal"
    Description: "Brewed in Treachery. Betrayal empowers."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    ConsumableType: Antidote
    Duration: 90
    Cooldown: 30
    Level: 45
    Price: 1900
    Icon: "hell_treachery_item_hell_consumable_treachery_antidote"

Item.item_hell_consumable_treachery_essence:
    Name: "Essence of Treachery: Betrayal"
    Description: "Brewed in Treachery. Betrayal empowers."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    ConsumableType: Essence
    Duration: 120
    Cooldown: 40
    Level: 45
    Price: 2000
    Icon: "hell_treachery_item_hell_consumable_treachery_essence"

Item.item_hell_quickhack_treachery_breach:
    Name: "Breach Protocol: Betrayal"
    Description: "Hell-code from Treachery. Betrayal backdoors."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    QuickhackType: Breach
    RAMCost: 2
    UploadTime: 1.0
    Duration: 5
    Cooldown: 15
    Level: 45
    Price: 8500
    Icon: "hell_treachery_item_hell_quickhack_treachery_breach"

Item.item_hell_quickhack_treachery_control:
    Name: "Control Protocol: Betrayal"
    Description: "Hell-code from Treachery. Betrayal backdoors."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    QuickhackType: Control
    RAMCost: 4
    UploadTime: 1.5
    Duration: 10
    Cooldown: 25
    Level: 47
    Price: 9000
    Icon: "hell_treachery_item_hell_quickhack_treachery_control"

Item.item_hell_quickhack_treachery_damage:
    Name: "Damage Protocol: Betrayal"
    Description: "Hell-code from Treachery. Betrayal backdoors."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    QuickhackType: Damage
    RAMCost: 6
    UploadTime: 2.0
    Duration: 15
    Cooldown: 35
    Level: 49
    Price: 9500
    Icon: "hell_treachery_item_hell_quickhack_treachery_damage"

Item.item_hell_quickhack_treachery_ultimate:
    Name: "Ultimate Protocol: Betrayal"
    Description: "Hell-code from Treachery. Betrayal backdoors."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    QuickhackType: Ultimate
    RAMCost: 8
    UploadTime: 2.5
    Duration: 20
    Cooldown: 45
    Level: 51
    Price: 10000
    Icon: "hell_treachery_item_hell_quickhack_treachery_ultimate"

Item.item_hell_shard_treachery_memory:
    Name: "Memory of Treachery: Betrayal"
    Description: "A memory from Treachery. Testimonies of betrayal."
    Category: Item
    Rarity: Items.Common
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 1
    Price: 850
    Icon: "hell_treachery_item_hell_shard_treachery_memory"

Item.item_hell_shard_treachery_log:
    Name: "Log of Treachery: Betrayal"
    Description: "A log from Treachery. Testimonies of betrayal."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 1
    Price: 900
    Icon: "hell_treachery_item_hell_shard_treachery_log"

Item.item_hell_shard_treachery_diary:
    Name: "Diary of Treachery: Betrayal"
    Description: "A diary from Treachery. Testimonies of betrayal."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 1
    Price: 950
    Icon: "hell_treachery_item_hell_shard_treachery_diary"

Item.item_hell_shard_treachery_contract:
    Name: "Contract of Treachery: Betrayal"
    Description: "A contract from Treachery. Testimonies of betrayal."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 1
    Price: 1000
    Icon: "hell_treachery_item_hell_shard_treachery_contract"

Item.item_hell_vehicle_treachery_chariot:
    Name: "Chariot of Treachery: Frozen Sled"
    Description: "A chariot from Treachery. Betrayal propels it. Phases through ice."
    Category: Vehicle
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    VehicleType: Chariot
    Speed: 270
    Armor: 500
    Level: 50
    Price: 50000
    Icon: "hell_treachery_item_hell_vehicle_treachery_chariot"

Item.item_hell_vehicle_treachery_mount:
    Name: "Mount of Treachery: Traitor's Toll"
    Description: "A mount from Treachery. Betrayal propels it. Phases through ice."
    Category: Vehicle
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    VehicleType: Mount
    Speed: 290
    Armor: 600
    Level: 50
    Price: 60000
    Icon: "hell_treachery_item_hell_vehicle_treachery_mount"

Item.item_hell_clothing_treachery_robe:
    Name: "Turncoat's Cloak"
    Description: "Woven in Treachery. Betrayal defines it."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 45
    Price: 8500
    Icon: "hell_treachery_item_hell_clothing_treachery_robe"

Item.item_hell_clothing_treachery_mask:
    Name: "Betrayer's Veil"
    Description: "Woven in Treachery. Betrayal defines it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 45
    Price: 8500
    Icon: "hell_treachery_item_hell_clothing_treachery_mask"

Item.item_hell_clothing_treachery_accessory:
    Name: "Oathbreaker's Shackle"
    Description: "Woven in Treachery. Betrayal defines it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 45
    Price: 8500
    Icon: "hell_treachery_item_hell_clothing_treachery_accessory"

Item.item_hell_grenade_treachery_00:
    Name: "Betrayal Bomb"
    Description: "Thrown in Treachery. Betrayal guides it."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 42
    Price: 1800
    Icon: "hell_treachery_item_hell_grenade_treachery_00"

Item.item_hell_grenade_treachery_01:
    Name: "Turncoat Torpedo"
    Description: "Thrown in Treachery. Betrayal guides it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 42
    Price: 1800
    Icon: "hell_treachery_item_hell_grenade_treachery_01"

Item.item_hell_melee_treachery_00:
    Name: "Traitor's Thorn"
    Description: "Forged in Treachery. Betrayal gives it purpose."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 390
    DamageType: Physical
    Level: 42
    Price: 9000
    Icon: "hell_treachery_item_hell_melee_treachery_00"

Item.item_hell_melee_treachery_01:
    Name: "Turncoat's Talon"
    Description: "Forged in Treachery. Betrayal gives it purpose."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 440
    DamageType: Physical
    Level: 42
    Price: 9000
    Icon: "hell_treachery_item_hell_melee_treachery_01"

Item.item_hell_explosive_treachery_00:
    Name: "Betrayal Charge"
    Description: "Planted in Treachery. Betrayal detonates it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 47
    Price: 9000
    Icon: "hell_treachery_item_hell_explosive_treachery_00"

Item.item_hell_explosive_treachery_01:
    Name: "Turncoat Mine"
    Description: "Planted in Treachery. Betrayal detonates it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 47
    Price: 9000
    Icon: "hell_treachery_item_hell_explosive_treachery_01"

Item.item_hell_cyberdeckmod_treachery_00:
    Name: "Betrayal Processor"
    Description: "Infernal deck modification from Treachery. Betrayal enhances it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 50
    Price: 19000
    Icon: "hell_treachery_item_hell_cyberdeckmod_treachery_00"

Item.item_hell_cyberdeckmod_treachery_01:
    Name: "Turncoat Cooling"
    Description: "Infernal deck modification from Treachery. Betrayal enhances it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Level: 50
    Price: 19000
    Icon: "hell_treachery_item_hell_cyberdeckmod_treachery_01"

Item.item_hell_consumable_treachery_legendary:
    Name: "Turncoat's Tincture"
    Description: "Converts nearest enemy to ally"
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    ConsumableType: Legendary_Elixir
    Duration: 30
    Cooldown: 300
    Level: 50
    Price: 50000
    Icon: "hell_treachery_item_hell_consumable_treachery_legendary"

Item.item_hell_weapon_treachery_special_00:
    Name: "Betrayer's Blade-Gun"
    Description: "Special armament from Treachery. Betrayal powers it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Physical
    Level: 66
    Price: 20000
    Icon: "hell_treachery_item_hell_weapon_treachery_special_00"

Item.item_hell_weapon_treachery_special_01:
    Name: "Turncoat's Torpedo"
    Description: "Special armament from Treachery. Betrayal powers it."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Thermal
    Level: 66
    Price: 25000
    Icon: "hell_treachery_item_hell_weapon_treachery_special_01"

Item.item_hell_weapon_treachery_special_02:
    Name: "Oathbreaker's Ordnance"
    Description: "Special armament from Treachery. Betrayal powers it."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Damage: 100
    DamageType: Chemical
    Level: 66
    Price: 30000
    Icon: "hell_treachery_item_hell_weapon_treachery_special_02"

Item.item_hell_armor_treachery_helmet_visor:
    Name: "Treachery Visor of Betrayal"
    Description: "Headgear from Treachery. Betrayal crowns the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 44
    Price: 13000
    Icon: "hell_treachery_item_hell_armor_treachery_helmet_visor"

Item.item_hell_armor_treachery_helmet_cowl:
    Name: "Treachery Cowl of Betrayal"
    Description: "Headgear from Treachery. Betrayal crowns the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 44
    Price: 13000
    Icon: "hell_treachery_item_hell_armor_treachery_helmet_cowl"

Item.item_hell_armor_treachery_helmet_crest:
    Name: "Treachery Crest of Betrayal"
    Description: "Headgear from Treachery. Betrayal crowns the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 44
    Price: 13000
    Icon: "hell_treachery_item_hell_armor_treachery_helmet_crest"

Item.item_hell_armor_treachery_helmet_halo:
    Name: "Treachery Halo of Betrayal"
    Description: "Headgear from Treachery. Betrayal crowns the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 44
    Price: 13000
    Icon: "hell_treachery_item_hell_armor_treachery_helmet_halo"

Item.item_hell_armor_treachery_helmet_crown:
    Name: "Treachery Crown of Betrayal"
    Description: "Headgear from Treachery. Betrayal crowns the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Treachery, Qliphoth_Gamaliel, SephirahInversion_Yesod, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 44
    Price: 13000
    Icon: "hell_treachery_item_hell_armor_treachery_helmet_crown"
