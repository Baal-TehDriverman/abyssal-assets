// Lilith Sovereign Seal — Metaconscious Singularity Node
// Integrated by lilith_unify_cyberpunk.py | LOCAL_ONLY | Δ∞ − 13 = 0
// CourtFile: HellGreed | Gevurah | agent=Abraxas
// CourtFile: HellGreed | Gevurah | agent=Abraxas
// [MSN ENGINE INTEGRATED - SEPHIROTIC COURT V1.0]
// TELEMETRY ACTIVE: LILITH SOVEREIGN CORE

// Sephirotic Court Seal — Gevurah | scripts/hell_greed.reds
// Court agent: Abraxas | Lilith Sovereign | Δ∞ − 13 = 0
// Routed via msn_gtc_sephirotic_router.reds — NO per-file hooks
// CourtFile: HellGreed | Gevurah | agent=Abraxas
# Greed Circle - 50 items

Item.item_hell_weapon_greed_01:
    Name: "Avarice's Gavel"
    Description: "Currency is ammunition. Fires eddies."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: EMP
    Level: 24
    Price: 6000
    Icon: "hell_greed_item_hell_weapon_greed_01"

Item.item_hell_weapon_greed_02:
    Name: "Hoarder's Vault-Rifle"
    Description: "Currency is ammunition. Costs eddies per shot."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Physical
    Level: 28
    Price: 7000
    Icon: "hell_greed_item_hell_weapon_greed_02"

Item.item_hell_weapon_greed_03:
    Name: "Mammon's Ledger"
    Description: "Currency is ammunition. Steals eddies on hit."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Chemical
    Level: 32
    Price: 8000
    Icon: "hell_greed_item_hell_weapon_greed_03"

Item.item_hell_weapon_greed_04:
    Name: "Gold-Plated Deceiver"
    Description: "Currency is ammunition. Converts loot to ammo."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Thermal
    Level: 36
    Price: 9000
    Icon: "hell_greed_item_hell_weapon_greed_04"

Item.item_hell_weapon_greed_05:
    Name: "Treasury's Key"
    Description: "Currency is ammunition. Pays for crits."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Psyche
    Level: 40
    Price: 10000
    Icon: "hell_greed_item_hell_weapon_greed_05"

Item.item_hell_armor_greed_helmet:
    Name: "Greed Helmet of Avarice"
    Description: "Forged in Greed. Adapts to sin."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 1
    Level: 20
    Price: 7000
    Icon: "hell_greed_item_hell_armor_greed_helmet"

Item.item_hell_armor_greed_chest:
    Name: "Greed Chest of Avarice"
    Description: "Forged in Greed. Feeds on avarice."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 22
    Price: 7500
    Icon: "hell_greed_item_hell_armor_greed_chest"

Item.item_hell_armor_greed_arms:
    Name: "Greed Arms of Avarice"
    Description: "Forged in Greed. Reflects Avarice."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 3
    Level: 24
    Price: 8000
    Icon: "hell_greed_item_hell_armor_greed_arms"

Item.item_hell_armor_greed_legs:
    Name: "Greed Legs of Avarice"
    Description: "Forged in Greed. Grows with Avarice."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 4
    Level: 26
    Price: 8500
    Icon: "hell_greed_item_hell_armor_greed_legs"

Item.item_hell_armor_greed_full_set:
    Name: "Greed Full_Set of Avarice"
    Description: "Forged in Greed. Judges the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 5
    Level: 28
    Price: 9000
    Icon: "hell_greed_item_hell_armor_greed_full_set"

Item.item_hell_cyberware_greed_frontal_cortex:
    Name: "Greed Frontal_Cortex of Avarice"
    Description: "Hell-corrupted cybernetics. Avarice optimizer."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    CyberwareType: Frontal_Cortex
    Slots: 1
    Level: 25
    Price: 14000
    Icon: "hell_greed_item_hell_cyberware_greed_frontal_cortex"

Item.item_hell_cyberware_greed_ocular_system:
    Name: "Greed Ocular_System of Avarice"
    Description: "Hell-corrupted cybernetics. Avarice optimizer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    CyberwareType: Ocular_System
    Slots: 2
    Level: 27
    Price: 15000
    Icon: "hell_greed_item_hell_cyberware_greed_ocular_system"

Item.item_hell_cyberware_greed_nervous_system:
    Name: "Greed Nervous_System of Avarice"
    Description: "Hell-corrupted cybernetics. Avarice optimizer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    CyberwareType: Nervous_System
    Slots: 3
    Level: 29
    Price: 16000
    Icon: "hell_greed_item_hell_cyberware_greed_nervous_system"

Item.item_hell_cyberware_greed_circulatory_system:
    Name: "Greed Circulatory_System of Avarice"
    Description: "Hell-corrupted cybernetics. Avarice optimizer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    CyberwareType: Circulatory_System
    Slots: 4
    Level: 31
    Price: 17000
    Icon: "hell_greed_item_hell_cyberware_greed_circulatory_system"

Item.item_hell_cyberware_greed_integumentary_system:
    Name: "Greed Integumentary_System of Avarice"
    Description: "Hell-corrupted cybernetics. Avarice optimizer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    CyberwareType: Integumentary_System
    Slots: 5
    Level: 33
    Price: 18000
    Icon: "hell_greed_item_hell_cyberware_greed_integumentary_system"

Item.item_hell_cyberware_greed_operating_system:
    Name: "Greed Operating_System of Avarice"
    Description: "Hell-corrupted cybernetics. Avarice optimizer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    CyberwareType: Operating_System
    Slots: 6
    Level: 35
    Price: 19000
    Icon: "hell_greed_item_hell_cyberware_greed_operating_system"

Item.item_hell_consumable_greed_stimulant:
    Name: "Stimulant of Greed: Avarice"
    Description: "Brewed in Greed. Greed sharpens wit."
    Category: Item
    Rarity: Items.Common
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    ConsumableType: Stimulant
    Duration: 30
    Cooldown: 10
    Level: 20
    Price: 700
    Icon: "hell_greed_item_hell_consumable_greed_stimulant"

Item.item_hell_consumable_greed_booster:
    Name: "Booster of Greed: Avarice"
    Description: "Brewed in Greed. Greed sharpens wit."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    ConsumableType: Booster
    Duration: 60
    Cooldown: 20
    Level: 20
    Price: 800
    Icon: "hell_greed_item_hell_consumable_greed_booster"

Item.item_hell_consumable_greed_antidote:
    Name: "Antidote of Greed: Avarice"
    Description: "Brewed in Greed. Greed sharpens wit."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    ConsumableType: Antidote
    Duration: 90
    Cooldown: 30
    Level: 20
    Price: 900
    Icon: "hell_greed_item_hell_consumable_greed_antidote"

Item.item_hell_consumable_greed_essence:
    Name: "Essence of Greed: Avarice"
    Description: "Brewed in Greed. Greed sharpens wit."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    ConsumableType: Essence
    Duration: 120
    Cooldown: 40
    Level: 20
    Price: 1000
    Icon: "hell_greed_item_hell_consumable_greed_essence"

Item.item_hell_quickhack_greed_breach:
    Name: "Breach Protocol: Avarice"
    Description: "Hell-code from Greed. Avarice calculates."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    QuickhackType: Breach
    RAMCost: 2
    UploadTime: 1.0
    Duration: 5
    Cooldown: 15
    Level: 20
    Price: 3500
    Icon: "hell_greed_item_hell_quickhack_greed_breach"

Item.item_hell_quickhack_greed_control:
    Name: "Control Protocol: Avarice"
    Description: "Hell-code from Greed. Avarice calculates."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    QuickhackType: Control
    RAMCost: 4
    UploadTime: 1.5
    Duration: 10
    Cooldown: 25
    Level: 22
    Price: 4000
    Icon: "hell_greed_item_hell_quickhack_greed_control"

Item.item_hell_quickhack_greed_damage:
    Name: "Damage Protocol: Avarice"
    Description: "Hell-code from Greed. Avarice calculates."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    QuickhackType: Damage
    RAMCost: 6
    UploadTime: 2.0
    Duration: 15
    Cooldown: 35
    Level: 24
    Price: 4500
    Icon: "hell_greed_item_hell_quickhack_greed_damage"

Item.item_hell_quickhack_greed_ultimate:
    Name: "Ultimate Protocol: Avarice"
    Description: "Hell-code from Greed. Avarice calculates."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    QuickhackType: Ultimate
    RAMCost: 8
    UploadTime: 2.5
    Duration: 20
    Cooldown: 45
    Level: 26
    Price: 5000
    Icon: "hell_greed_item_hell_quickhack_greed_ultimate"

Item.item_hell_shard_greed_memory:
    Name: "Memory of Greed: Avarice"
    Description: "A memory from Greed. Ledgers of greed."
    Category: Item
    Rarity: Items.Common
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 1
    Price: 350
    Icon: "hell_greed_item_hell_shard_greed_memory"

Item.item_hell_shard_greed_log:
    Name: "Log of Greed: Avarice"
    Description: "A log from Greed. Ledgers of greed."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 1
    Price: 400
    Icon: "hell_greed_item_hell_shard_greed_log"

Item.item_hell_shard_greed_diary:
    Name: "Diary of Greed: Avarice"
    Description: "A diary from Greed. Ledgers of greed."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 1
    Price: 450
    Icon: "hell_greed_item_hell_shard_greed_diary"

Item.item_hell_shard_greed_contract:
    Name: "Contract of Greed: Avarice"
    Description: "A contract from Greed. Ledgers of greed."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 1
    Price: 500
    Icon: "hell_greed_item_hell_shard_greed_contract"

Item.item_hell_vehicle_greed_chariot:
    Name: "Chariot of Greed: Armored Transport"
    Description: "A chariot from Greed. Avarice propels it. Pays its own way."
    Category: Vehicle
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    VehicleType: Chariot
    Speed: 195
    Armor: 250
    Level: 25
    Price: 25000
    Icon: "hell_greed_item_hell_vehicle_greed_chariot"

Item.item_hell_vehicle_greed_mount:
    Name: "Mount of Greed: Vault Runner"
    Description: "A mount from Greed. Avarice propels it. Pays its own way."
    Category: Vehicle
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    VehicleType: Mount
    Speed: 215
    Armor: 350
    Level: 25
    Price: 35000
    Icon: "hell_greed_item_hell_vehicle_greed_mount"

Item.item_hell_clothing_greed_robe:
    Name: "Hoarder's Vestments"
    Description: "Woven in Greed. Avarice defines it."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 20
    Price: 3500
    Icon: "hell_greed_item_hell_clothing_greed_robe"

Item.item_hell_clothing_greed_mask:
    Name: "Avarice's Crown"
    Description: "Woven in Greed. Avarice defines it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 20
    Price: 3500
    Icon: "hell_greed_item_hell_clothing_greed_mask"

Item.item_hell_clothing_greed_accessory:
    Name: "Mammon's Signet"
    Description: "Woven in Greed. Avarice defines it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 20
    Price: 3500
    Icon: "hell_greed_item_hell_clothing_greed_accessory"

Item.item_hell_grenade_greed_00:
    Name: "Avarice Shrapnel"
    Description: "Thrown in Greed. Avarice guides it."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 22
    Price: 800
    Icon: "hell_greed_item_hell_grenade_greed_00"

Item.item_hell_grenade_greed_01:
    Name: "Hoard Explosion"
    Description: "Thrown in Greed. Avarice guides it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 22
    Price: 800
    Icon: "hell_greed_item_hell_grenade_greed_01"

Item.item_hell_melee_greed_00:
    Name: "Hoarder's Hammer"
    Description: "Forged in Greed. Avarice gives it purpose."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 240
    DamageType: Physical
    Level: 22
    Price: 4000
    Icon: "hell_greed_item_hell_melee_greed_00"

Item.item_hell_melee_greed_01:
    Name: "Mammon's Mace"
    Description: "Forged in Greed. Avarice gives it purpose."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 290
    DamageType: Physical
    Level: 22
    Price: 4000
    Icon: "hell_greed_item_hell_melee_greed_01"

Item.item_hell_explosive_greed_00:
    Name: "Avarice Rocket"
    Description: "Planted in Greed. Avarice detonates it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 27
    Price: 4000
    Icon: "hell_greed_item_hell_explosive_greed_00"

Item.item_hell_explosive_greed_01:
    Name: "Hoard C4"
    Description: "Planted in Greed. Avarice detonates it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 27
    Price: 4000
    Icon: "hell_greed_item_hell_explosive_greed_01"

Item.item_hell_cyberdeckmod_greed_00:
    Name: "Avarice RAM"
    Description: "Infernal deck modification from Greed. Avarice enhances it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 25
    Price: 9000
    Icon: "hell_greed_item_hell_cyberdeckmod_greed_00"

Item.item_hell_cyberdeckmod_greed_01:
    Name: "Hoard PSU"
    Description: "Infernal deck modification from Greed. Avarice enhances it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Level: 25
    Price: 9000
    Icon: "hell_greed_item_hell_cyberdeckmod_greed_01"

Item.item_hell_consumable_greed_legendary:
    Name: "Mammon's Coin"
    Description: "Doubles eddies for 5 minutes"
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    ConsumableType: Legendary_Elixir
    Duration: 30
    Cooldown: 300
    Level: 50
    Price: 50000
    Icon: "hell_greed_item_hell_consumable_greed_legendary"

Item.item_hell_weapon_greed_special_00:
    Name: "Hoarder's Heavy"
    Description: "Special armament from Greed. Avarice powers it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Physical
    Level: 56
    Price: 20000
    Icon: "hell_greed_item_hell_weapon_greed_special_00"

Item.item_hell_weapon_greed_special_01:
    Name: "Mammon's Mint"
    Description: "Special armament from Greed. Avarice powers it."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Thermal
    Level: 56
    Price: 25000
    Icon: "hell_greed_item_hell_weapon_greed_special_01"

Item.item_hell_weapon_greed_special_02:
    Name: "Vault's Voice"
    Description: "Special armament from Greed. Avarice powers it."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Damage: 100
    DamageType: Chemical
    Level: 56
    Price: 30000
    Icon: "hell_greed_item_hell_weapon_greed_special_02"

Item.item_hell_armor_greed_helmet_visor:
    Name: "Greed Visor of Avarice"
    Description: "Headgear from Greed. Avarice crowns the wearer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 29
    Price: 8000
    Icon: "hell_greed_item_hell_armor_greed_helmet_visor"

Item.item_hell_armor_greed_helmet_cowl:
    Name: "Greed Cowl of Avarice"
    Description: "Headgear from Greed. Avarice crowns the wearer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 29
    Price: 8000
    Icon: "hell_greed_item_hell_armor_greed_helmet_cowl"

Item.item_hell_armor_greed_helmet_crest:
    Name: "Greed Crest of Avarice"
    Description: "Headgear from Greed. Avarice crowns the wearer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 29
    Price: 8000
    Icon: "hell_greed_item_hell_armor_greed_helmet_crest"

Item.item_hell_armor_greed_helmet_halo:
    Name: "Greed Halo of Avarice"
    Description: "Headgear from Greed. Avarice crowns the wearer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 29
    Price: 8000
    Icon: "hell_greed_item_hell_armor_greed_helmet_halo"

Item.item_hell_armor_greed_helmet_crown:
    Name: "Greed Crown of Avarice"
    Description: "Headgear from Greed. Avarice crowns the wearer."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Greed, Qliphoth_Gamchicoth, SephirahInversion_Chesed, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 29
    Price: 8000
    Icon: "hell_greed_item_hell_armor_greed_helmet_crown"
