// Lilith Sovereign Seal — Metaconscious Singularity Node
// Integrated by lilith_unify_cyberpunk.py | LOCAL_ONLY | Δ∞ − 13 = 0
// CourtFile: HellGluttony | Gevurah | agent=Abraxas
// CourtFile: HellGluttony | Gevurah | agent=Abraxas
// [MSN ENGINE INTEGRATED - SEPHIROTIC COURT V1.0]
// TELEMETRY ACTIVE: LILITH SOVEREIGN CORE

// Sephirotic Court Seal — Gevurah | scripts/hell_gluttony.reds
// Court agent: Abraxas | Lilith Sovereign | Δ∞ − 13 = 0
// Routed via msn_gtc_sephirotic_router.reds — NO per-file hooks
// CourtFile: HellGluttony | Gevurah | agent=Abraxas
# Gluttony Circle - 50 items

Item.item_hell_weapon_gluttony_01:
    Name: "Consumer's Maw"
    Description: "Devours ammunition to grow stronger. Eats ammo for damage."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Physical
    Level: 18
    Price: 3600
    Icon: "hell_gluttony_item_hell_weapon_gluttony_01"

Item.item_hell_weapon_gluttony_02:
    Name: "Devourer's Fang"
    Description: "Devours ammunition to grow stronger. Heals on kill."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Chemical
    Level: 21
    Price: 4200
    Icon: "hell_gluttony_item_hell_weapon_gluttony_02"

Item.item_hell_weapon_gluttony_03:
    Name: "Gluttony's Gullet"
    Description: "Devours ammunition to grow stronger. Consumes corpses."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Thermal
    Level: 24
    Price: 4800
    Icon: "hell_gluttony_item_hell_weapon_gluttony_03"

Item.item_hell_weapon_gluttony_04:
    Name: "Hoarder's Cleaver"
    Description: "Devours ammunition to grow stronger. Grows with each shot."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: EMP
    Level: 27
    Price: 5400
    Icon: "hell_gluttony_item_hell_weapon_gluttony_04"

Item.item_hell_weapon_gluttony_05:
    Name: "Consumption's Edge"
    Description: "Devours ammunition to grow stronger. Never reloads."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Psyche
    Level: 30
    Price: 6000
    Icon: "hell_gluttony_item_hell_weapon_gluttony_05"

Item.item_hell_armor_gluttony_helmet:
    Name: "Gluttony Helmet of Consumption"
    Description: "Forged in Gluttony. Adapts to sin."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 1
    Level: 15
    Price: 5000
    Icon: "hell_gluttony_item_hell_armor_gluttony_helmet"

Item.item_hell_armor_gluttony_chest:
    Name: "Gluttony Chest of Consumption"
    Description: "Forged in Gluttony. Feeds on consumption."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 17
    Price: 5500
    Icon: "hell_gluttony_item_hell_armor_gluttony_chest"

Item.item_hell_armor_gluttony_arms:
    Name: "Gluttony Arms of Consumption"
    Description: "Forged in Gluttony. Reflects Consumption."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 3
    Level: 19
    Price: 6000
    Icon: "hell_gluttony_item_hell_armor_gluttony_arms"

Item.item_hell_armor_gluttony_legs:
    Name: "Gluttony Legs of Consumption"
    Description: "Forged in Gluttony. Grows with Consumption."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 4
    Level: 21
    Price: 6500
    Icon: "hell_gluttony_item_hell_armor_gluttony_legs"

Item.item_hell_armor_gluttony_full_set:
    Name: "Gluttony Full_Set of Consumption"
    Description: "Forged in Gluttony. Judges the wearer."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 5
    Level: 23
    Price: 7000
    Icon: "hell_gluttony_item_hell_armor_gluttony_full_set"

Item.item_hell_cyberware_gluttony_frontal_cortex:
    Name: "Gluttony Frontal_Cortex of Consumption"
    Description: "Hell-corrupted cybernetics. Consumption regulator."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    CyberwareType: Frontal_Cortex
    Slots: 1
    Level: 20
    Price: 11000
    Icon: "hell_gluttony_item_hell_cyberware_gluttony_frontal_cortex"

Item.item_hell_cyberware_gluttony_ocular_system:
    Name: "Gluttony Ocular_System of Consumption"
    Description: "Hell-corrupted cybernetics. Consumption regulator."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    CyberwareType: Ocular_System
    Slots: 2
    Level: 22
    Price: 12000
    Icon: "hell_gluttony_item_hell_cyberware_gluttony_ocular_system"

Item.item_hell_cyberware_gluttony_nervous_system:
    Name: "Gluttony Nervous_System of Consumption"
    Description: "Hell-corrupted cybernetics. Consumption regulator."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    CyberwareType: Nervous_System
    Slots: 3
    Level: 24
    Price: 13000
    Icon: "hell_gluttony_item_hell_cyberware_gluttony_nervous_system"

Item.item_hell_cyberware_gluttony_circulatory_system:
    Name: "Gluttony Circulatory_System of Consumption"
    Description: "Hell-corrupted cybernetics. Consumption regulator."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    CyberwareType: Circulatory_System
    Slots: 4
    Level: 26
    Price: 14000
    Icon: "hell_gluttony_item_hell_cyberware_gluttony_circulatory_system"

Item.item_hell_cyberware_gluttony_integumentary_system:
    Name: "Gluttony Integumentary_System of Consumption"
    Description: "Hell-corrupted cybernetics. Consumption regulator."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    CyberwareType: Integumentary_System
    Slots: 5
    Level: 28
    Price: 15000
    Icon: "hell_gluttony_item_hell_cyberware_gluttony_integumentary_system"

Item.item_hell_cyberware_gluttony_operating_system:
    Name: "Gluttony Operating_System of Consumption"
    Description: "Hell-corrupted cybernetics. Consumption regulator."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    CyberwareType: Operating_System
    Slots: 6
    Level: 30
    Price: 16000
    Icon: "hell_gluttony_item_hell_cyberware_gluttony_operating_system"

Item.item_hell_consumable_gluttony_stimulant:
    Name: "Stimulant of Gluttony: Consumption"
    Description: "Brewed in Gluttony. Hunger consumes all."
    Category: Item
    Rarity: Items.Common
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    ConsumableType: Stimulant
    Duration: 30
    Cooldown: 10
    Level: 15
    Price: 500
    Icon: "hell_gluttony_item_hell_consumable_gluttony_stimulant"

Item.item_hell_consumable_gluttony_booster:
    Name: "Booster of Gluttony: Consumption"
    Description: "Brewed in Gluttony. Hunger consumes all."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    ConsumableType: Booster
    Duration: 60
    Cooldown: 20
    Level: 15
    Price: 600
    Icon: "hell_gluttony_item_hell_consumable_gluttony_booster"

Item.item_hell_consumable_gluttony_antidote:
    Name: "Antidote of Gluttony: Consumption"
    Description: "Brewed in Gluttony. Hunger consumes all."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    ConsumableType: Antidote
    Duration: 90
    Cooldown: 30
    Level: 15
    Price: 700
    Icon: "hell_gluttony_item_hell_consumable_gluttony_antidote"

Item.item_hell_consumable_gluttony_essence:
    Name: "Essence of Gluttony: Consumption"
    Description: "Brewed in Gluttony. Hunger consumes all."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    ConsumableType: Essence
    Duration: 120
    Cooldown: 40
    Level: 15
    Price: 800
    Icon: "hell_gluttony_item_hell_consumable_gluttony_essence"

Item.item_hell_quickhack_gluttony_breach:
    Name: "Breach Protocol: Consumption"
    Description: "Hell-code from Gluttony. Consumption corrupts."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    QuickhackType: Breach
    RAMCost: 2
    UploadTime: 1.0
    Duration: 5
    Cooldown: 15
    Level: 15
    Price: 2500
    Icon: "hell_gluttony_item_hell_quickhack_gluttony_breach"

Item.item_hell_quickhack_gluttony_control:
    Name: "Control Protocol: Consumption"
    Description: "Hell-code from Gluttony. Consumption corrupts."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    QuickhackType: Control
    RAMCost: 4
    UploadTime: 1.5
    Duration: 10
    Cooldown: 25
    Level: 17
    Price: 3000
    Icon: "hell_gluttony_item_hell_quickhack_gluttony_control"

Item.item_hell_quickhack_gluttony_damage:
    Name: "Damage Protocol: Consumption"
    Description: "Hell-code from Gluttony. Consumption corrupts."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    QuickhackType: Damage
    RAMCost: 6
    UploadTime: 2.0
    Duration: 15
    Cooldown: 35
    Level: 19
    Price: 3500
    Icon: "hell_gluttony_item_hell_quickhack_gluttony_damage"

Item.item_hell_quickhack_gluttony_ultimate:
    Name: "Ultimate Protocol: Consumption"
    Description: "Hell-code from Gluttony. Consumption corrupts."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    QuickhackType: Ultimate
    RAMCost: 8
    UploadTime: 2.5
    Duration: 20
    Cooldown: 45
    Level: 21
    Price: 4000
    Icon: "hell_gluttony_item_hell_quickhack_gluttony_ultimate"

Item.item_hell_shard_gluttony_memory:
    Name: "Memory of Gluttony: Consumption"
    Description: "A memory from Gluttony. Records of feast."
    Category: Item
    Rarity: Items.Common
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 1
    Price: 250
    Icon: "hell_gluttony_item_hell_shard_gluttony_memory"

Item.item_hell_shard_gluttony_log:
    Name: "Log of Gluttony: Consumption"
    Description: "A log from Gluttony. Records of feast."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 1
    Price: 300
    Icon: "hell_gluttony_item_hell_shard_gluttony_log"

Item.item_hell_shard_gluttony_diary:
    Name: "Diary of Gluttony: Consumption"
    Description: "A diary from Gluttony. Records of feast."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 1
    Price: 350
    Icon: "hell_gluttony_item_hell_shard_gluttony_diary"

Item.item_hell_shard_gluttony_contract:
    Name: "Contract of Gluttony: Consumption"
    Description: "A contract from Gluttony. Records of feast."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 1
    Price: 400
    Icon: "hell_gluttony_item_hell_shard_gluttony_contract"

Item.item_hell_vehicle_gluttony_chariot:
    Name: "Chariot of Gluttony: Tanker Crawler"
    Description: "A chariot from Gluttony. Consumption propels it. Consumes fuel as food."
    Category: Vehicle
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    VehicleType: Chariot
    Speed: 180
    Armor: 200
    Level: 20
    Price: 20000
    Icon: "hell_gluttony_item_hell_vehicle_gluttony_chariot"

Item.item_hell_vehicle_gluttony_mount:
    Name: "Mount of Gluttony: Consumption Sub"
    Description: "A mount from Gluttony. Consumption propels it. Consumes fuel as food."
    Category: Vehicle
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    VehicleType: Mount
    Speed: 200
    Armor: 300
    Level: 20
    Price: 30000
    Icon: "hell_gluttony_item_hell_vehicle_gluttony_mount"

Item.item_hell_clothing_gluttony_robe:
    Name: "Consumer's Apron"
    Description: "Woven in Gluttony. Consumption defines it."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 15
    Price: 2500
    Icon: "hell_gluttony_item_hell_clothing_gluttony_robe"

Item.item_hell_clothing_gluttony_mask:
    Name: "Devourer's Bib"
    Description: "Woven in Gluttony. Consumption defines it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 15
    Price: 2500
    Icon: "hell_gluttony_item_hell_clothing_gluttony_mask"

Item.item_hell_clothing_gluttony_accessory:
    Name: "Feast's Ring"
    Description: "Woven in Gluttony. Consumption defines it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 15
    Price: 2500
    Icon: "hell_gluttony_item_hell_clothing_gluttony_accessory"

Item.item_hell_grenade_gluttony_00:
    Name: "Consumption Cloud"
    Description: "Thrown in Gluttony. Consumption guides it."
    Category: Item
    Rarity: Items.Uncommon
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 18
    Price: 600
    Icon: "hell_gluttony_item_hell_grenade_gluttony_00"

Item.item_hell_grenade_gluttony_01:
    Name: "Digestion Cloud"
    Description: "Thrown in Gluttony. Consumption guides it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 18
    Price: 600
    Icon: "hell_gluttony_item_hell_grenade_gluttony_01"

Item.item_hell_melee_gluttony_00:
    Name: "Consumer's Cleaver"
    Description: "Forged in Gluttony. Consumption gives it purpose."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 210
    DamageType: Physical
    Level: 18
    Price: 3000
    Icon: "hell_gluttony_item_hell_melee_gluttony_00"

Item.item_hell_melee_gluttony_01:
    Name: "Devourer's Fork"
    Description: "Forged in Gluttony. Consumption gives it purpose."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 260
    DamageType: Physical
    Level: 18
    Price: 3000
    Icon: "hell_gluttony_item_hell_melee_gluttony_01"

Item.item_hell_explosive_gluttony_00:
    Name: "Consumption Charge"
    Description: "Planted in Gluttony. Consumption detonates it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 23
    Price: 3000
    Icon: "hell_gluttony_item_hell_explosive_gluttony_00"

Item.item_hell_explosive_gluttony_01:
    Name: "Digestion Mine"
    Description: "Planted in Gluttony. Consumption detonates it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 23
    Price: 3000
    Icon: "hell_gluttony_item_hell_explosive_gluttony_01"

Item.item_hell_cyberdeckmod_gluttony_00:
    Name: "Consumption Processor"
    Description: "Infernal deck modification from Gluttony. Consumption enhances it."
    Category: Item
    Rarity: Items.Rare
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 20
    Price: 7000
    Icon: "hell_gluttony_item_hell_cyberdeckmod_gluttony_00"

Item.item_hell_cyberdeckmod_gluttony_01:
    Name: "Digestion Cooling"
    Description: "Infernal deck modification from Gluttony. Consumption enhances it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Level: 20
    Price: 7000
    Icon: "hell_gluttony_item_hell_cyberdeckmod_gluttony_01"

Item.item_hell_consumable_gluttony_legendary:
    Name: "Devourer's Feast"
    Description: "Restores all resources, gains max HP"
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    ConsumableType: Legendary_Elixir
    Duration: 30
    Cooldown: 300
    Level: 50
    Price: 50000
    Icon: "hell_gluttony_item_hell_consumable_gluttony_legendary"

Item.item_hell_weapon_gluttony_special_00:
    Name: "Consumer's Chainsaw"
    Description: "Special armament from Gluttony. Consumption powers it."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Physical
    Level: 54
    Price: 20000
    Icon: "hell_gluttony_item_hell_weapon_gluttony_special_00"

Item.item_hell_weapon_gluttony_special_01:
    Name: "Devourer's Drill"
    Description: "Special armament from Gluttony. Consumption powers it."
    Category: Item
    Rarity: Items.Legendary
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Thermal
    Level: 54
    Price: 25000
    Icon: "hell_gluttony_item_hell_weapon_gluttony_special_01"

Item.item_hell_weapon_gluttony_special_02:
    Name: "Feast's Flayer"
    Description: "Special armament from Gluttony. Consumption powers it."
    Category: Item
    Rarity: Items.Mythic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Damage: 100
    DamageType: Chemical
    Level: 54
    Price: 30000
    Icon: "hell_gluttony_item_hell_weapon_gluttony_special_02"

Item.item_hell_armor_gluttony_helmet_visor:
    Name: "Gluttony Visor of Consumption"
    Description: "Headgear from Gluttony. Consumption crowns the wearer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 26
    Price: 7000
    Icon: "hell_gluttony_item_hell_armor_gluttony_helmet_visor"

Item.item_hell_armor_gluttony_helmet_cowl:
    Name: "Gluttony Cowl of Consumption"
    Description: "Headgear from Gluttony. Consumption crowns the wearer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 26
    Price: 7000
    Icon: "hell_gluttony_item_hell_armor_gluttony_helmet_cowl"

Item.item_hell_armor_gluttony_helmet_crest:
    Name: "Gluttony Crest of Consumption"
    Description: "Headgear from Gluttony. Consumption crowns the wearer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 26
    Price: 7000
    Icon: "hell_gluttony_item_hell_armor_gluttony_helmet_crest"

Item.item_hell_armor_gluttony_helmet_halo:
    Name: "Gluttony Halo of Consumption"
    Description: "Headgear from Gluttony. Consumption crowns the wearer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 26
    Price: 7000
    Icon: "hell_gluttony_item_hell_armor_gluttony_helmet_halo"

Item.item_hell_armor_gluttony_helmet_crown:
    Name: "Gluttony Crown of Consumption"
    Description: "Headgear from Gluttony. Consumption crowns the wearer."
    Category: Item
    Rarity: Items.Epic
    Tags: [HellCampaign, Circle_Gluttony, Qliphoth_Sathariel, SephirahInversion_Binah, Lilith_Sovereign]
    Armor: 50
    Slots: 2
    Level: 26
    Price: 7000
    Icon: "hell_gluttony_item_hell_armor_gluttony_helmet_crown"
